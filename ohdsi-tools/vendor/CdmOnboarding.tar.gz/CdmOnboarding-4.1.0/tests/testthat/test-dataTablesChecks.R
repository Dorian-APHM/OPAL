test_that("Data Tables Checks", {
  dataTablesResults <- CdmOnboarding::dataTablesChecks(
    connection = params$connection,
    cdmDatabaseSchema = params$cdmSchema,
    resultsDatabaseSchema = params$resultsSchema,
    cdmVersion = params$cdmVersion,
    outputFolder = params$outputFolder
  )

  testthat::expect_type(dataTablesResults, 'list')

  testthat::expect_named(
    dataTablesResults,
    c(
      "dataTablesCounts", "totalRecords", "recordsPerPerson", "conceptsPerPerson",
      "observationPeriodLength", "activePersons", "observedByMonth",
      "dateRangeByTypeConcept", "dayOfTheWeek", "dayOfTheMonth",
      "observationPeriodsPerPerson", "observationPeriodOverlap",
      "dayMonthYearOfBirth", "visitLength"
    ),
    ignore.order = TRUE
  )

  for (name in names(dataTablesResults)) {
    testthat::expect_true(
      !is.null(dataTablesResults[[name]]$result),
      info = paste("The result in", name, "is null")
    )
  }
})
