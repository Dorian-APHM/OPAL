# @file DedChecks
#
# Copyright 2026 Darwin EU Coordination Center
#
# This file is part of CdmOnboarding
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# @author Darwin EU Coordination Center
# @author Maxim Moinat

#' Run DrugExposureDiagnostics for a set of default ingredient concepts
#' @param cdm An R object of type \code{cdm_reference}
#' @returns list of DED diagnostics_summary and duration
.runDedChecks <- function(cdm) {
  dedVersion <- packageVersion(pkg = "DrugExposureDiagnostics")
  if (dedVersion <= '1.0.5') {
    ParallelLogger::logError(sprintf(
      "Unsupported version of DrugExposureDiagnostics installed: %s.",
      dedVersion
    ))
    stop("Unsupported version of DrugExposureDiagnostics installed.")
  }

  dedIngredients <- getDedIngredients()
  ParallelLogger::logInfo(sprintf(
    "Starting execution of DrugExposureDiagnostics for %d ingredient%s",
    nrow(dedIngredients),
    if (nrow(dedIngredients) > 1) 's' else ''
  ))

  ded_start_time <- Sys.time()
  # Gives error when run as part of the package, but not when run individually;
  #   DED checks failed: Error in `dplyr::collect()`:
  # ! Failed to collect lazy table.
  # Caused by error:
  # ! Failed to prepare query : ERROR:  syntax error at or near ","
  # LINE 1: SELECT 1.*, route, concept_name AS ingredient_name
  dedResults <- tryCatch({
    DrugExposureDiagnostics::executeChecks(
      cdm = cdm,
      ingredients = dedIngredients$concept_id,
      checks = c("missing", "exposureDuration", "type", "route", "dose", "quantity", "diagnosticsSummary"),
      minCellCount = 5,
      sample = NULL,
      earliestStartDate = "2005-01-01"
    )
  }, error = function(e) {
    ParallelLogger::logError("DED checks failed: ", e)
    ParallelLogger::logError(conditionMessage(e))
    NULL
  })

  duration <- as.numeric(difftime(Sys.time(), ded_start_time), units = "secs")
  
  ParallelLogger::logInfo(sprintf("Executing DrugExposureDiagnostics took %.2f seconds.", duration))

  mappingLevel <- tryCatch({
    getMappingLevel(dedResults)
  }, error = function(e) {
    ParallelLogger::logWarn("Could not generate mapping level summary. ", e)
    NULL
  })

  # Return result with duration
  list(
    result = dedResults$diagnosticsSummary,
    resultMappingLevel = mappingLevel,
    duration = duration,
    packageVersion = dedVersion
  )
}

#' Get drug class levels from DrugExposureDiagnostics results
#' @param dedResults DrugExposureDiagnostics results object
#' @return data frame with for each ingredient and concept_class_id the number of concepts and records
#' @export
getMappingLevel <- function(dedResults) {
  if (is.null(dedResults)) {
    return(NULL)
  }
  dedResults$conceptSummary %>%
    dplyr::group_by(
      .data$ingredient,
      .data$concept_class_id
    ) %>%
    dplyr::summarise(
      n_concepts = n(),
      n_records = sum(.data$n_records, na.rm = TRUE)
    )
}

#' Returns data frame with concept_id and concept_name of drug ingredients
#' used for the DrugExposureDiagnostics check
#' @return data.frame ingredient concept_id and concept_name
#' @export
getDedIngredients <- function() {
  dedIngredients <- data.frame(
    concept_id = c(
      528323,
      954688,
      968426,
      1119119,
      1125315,
      1139042,
      1140643,
      1154343,
      1550557,
      1703687,
      40225722
    ),
    concept_name = c(
      "hepatitis B surface antigen vaccine",
      "latanoprost",
      "mesalamine",
      "adalimumab",
      "acetaminophen",
      "acetylcysteine",
      "sumatriptan",
      "albuterol",
      "prednisolone",
      "acyclovir",
      "ulipristal"
    )
  )
  return(dedIngredients)
}
