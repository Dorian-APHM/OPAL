# @file VocabularyCheck
#
# Copyright 2026 Darwin EU Coordination Center
#
# This file is part of CdmOnboarding
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# @author Darwin EU Coordination Center
# @author Peter Rijnbeek
# @author Maxim Moinat


#' The vocabulary checks (for v5.x)
#'
#' @description
#' \code{vocabularyChecks} runs a list of checks on the vocabulary as part of the CDM Onboarding procedure
#'
#' @details
#' \code{vocabularyChecks} runs a list of checks on the vocabulary as part of the CDM Onboarding procedure
#'
#' @param connection                       An R object of type \code{DatabaseConnectorDbiConnection}
#' @param cdmDatabaseSchema    	           Fully qualified name of database schema that contains OMOP CDM schema.
#'                                         On SQL Server, this should specifiy both the database and the schema, so for example, on SQL Server, 'cdm_instance.dbo'.
#' @param cdmVersion                       Define the OMOP CDM version used: currently supports v5 and above.
#'                                         Use major release number or minor number only (e.g. 5, 5.3)
#' @param smallCellCount                   To avoid patient identifiability, cells with small counts (<= smallCellCount) are deleted. Set to NULL if you don't want any deletions.
#' @param outputFolder                     Path to store logs and SQL files
#' @param optimize                         Boolean to determine if heuristics will be used to speed up execution. Currently only implemented for postgresql databases. Default = FALSE
#' @return                                 An object of type \code{achillesResults} containing details for connecting to the database containing the results
#' @export
vocabularyChecks <- function(connection,
                             cdmDatabaseSchema,
                             cdmVersion,
                             smallCellCount = 5,
                             outputFolder = "output",
                             optimize = FALSE) {
  if (optimize && connection@dbms == "postgresql") {
    vocabularyCounts <- executeQuery(outputFolder, "vocabulary_tables_count_postgres.sql", successMessage = "Count on vocabulary tables (postgres estimate) query executed successfully",
                                     connection = connection, cdmDatabaseSchema = cdmDatabaseSchema)
  } else if (optimize && connection@dbms == "sql server") {
    vocabularyCounts <- executeQuery(outputFolder, "vocabulary_tables_count_sql_server.sql", successMessage = "Count on vocabulary tables (sql server estimate) query executed successfully",
                                     connection = connection, cdmDatabaseSchema = cdmDatabaseSchema)
  } else {
    vocabularyCounts <- executeQuery(outputFolder, "vocabulary_tables_count.sql", successMessage = "Count on vocabulary tables query executed successfully",
                                     connection = connection, cdmDatabaseSchema = cdmDatabaseSchema)
  }

  conceptCounts <- executeQuery(outputFolder, "concept_counts_by_vocabulary.sql", successMessage = "Concept counts by vocabulary query executed successfully",
                                connection = connection, cdmDatabaseSchema = cdmDatabaseSchema)
  sourceConceptFrequency <- executeQuery(outputFolder, "source_to_concept_map_frequency.sql", successMessage = "Source to concept map breakdown query executed successfully",
                                         connection = connection, cdmDatabaseSchema = cdmDatabaseSchema)
  sourceConceptMap <- executeQuery(outputFolder, "get_source_to_concept_map.sql", successMessage = "Source to concept map query executed successfully",
                                   connection = connection, cdmDatabaseSchema = cdmDatabaseSchema)

  # Execute in same connection
  # Note: if one query in the tryCatch fails, then all fail ("current transaction is aborted")
  ParallelLogger::logInfo("Starting vocab mapping queries. Preprocessing domains...")
  mappingTempTableCreation <- executeQuery(outputFolder, "mapping_temp_tables.sql", successMessage = "Mapping Temp tables query executed successfully",
                                           connection = connection, useExecuteSql = TRUE, cdmDatabaseSchema = cdmDatabaseSchema, cdmVersion = cdmVersion, optimize = optimize)
  mappingCompleteness <- executeQuery(outputFolder, "mapping_completeness.sql", successMessage = "Mapping Completeness query executed successfully",
                                      connection = connection, cdmVersion = cdmVersion)

  drugMapping  <- executeQuery(outputFolder, "mapping_levels_drugs.sql", successMessage = "Drug Level Mapping query executed successfully",
                               connection = connection, cdmDatabaseSchema = cdmDatabaseSchema)

  unmappedDrugs <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped drugs query executed successfully",
                                connection = connection, cdmDomain = 'drug', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedConditions <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped conditions query executed successfully",
                                     connection = connection, cdmDomain = 'condition', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedMeasurements <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped measurements query executed successfully",
                                       connection = connection, cdmDomain = 'meas', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedObservations <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped observations query executed successfully",
                                       connection = connection, cdmDomain = 'obs', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedProcedures <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped procedures query executed successfully",
                                     connection = connection, cdmDomain = 'procedure', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedDevices <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped devices query executed successfully",
                                  connection = connection, cdmDomain = 'device', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedVisits <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped visits query executed successfully",
                                 connection = connection, cdmDomain = 'visit', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedVisitDetails <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped visit details query executed successfully",
                                       connection = connection, cdmDomain = 'visit_detail', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedUnitsMeas <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped meas units query executed successfully",
                                    connection = connection, cdmDomain = 'meas_unit', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedUnitsObs <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped obs units query executed successfully",
                                   connection = connection, cdmDomain = 'obs_unit', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedValuesMeas <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped meas values query executed successfully",
                                     connection = connection, cdmDomain = 'meas_value', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedValuesObs <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped obs values query executed successfully",
                                    connection = connection, cdmDomain = 'obs_value', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedDrugRoute <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped drug route query executed successfully",
                                    connection = connection, cdmDomain = 'drug_route', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  unmappedSpecialty <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped specialty query executed successfully",
                                    connection = connection, cdmDomain = 'specialty', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  if (cdmVersion >= 5.4) {
    unmappedEpisodes <- executeQuery(outputFolder, "unmapped_concepts_templated.sql", successMessage = "Unmapped episode query executed successfully",
                                     connection = connection, cdmDomain = 'eps', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  } else {
    unmappedEpisodes <- NULL
  }

  mappedDrugs <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped drugs query executed successfully",
                              connection = connection, cdmDomain = 'drug', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedConditions <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped conditions query executed successfully",
                                   connection = connection, cdmDomain = 'condition', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedMeasurements <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped measurements query executed successfully",
                                     connection = connection, cdmDomain = 'meas', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedObservations <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped observations query executed successfully",
                                     connection = connection, cdmDomain = 'obs', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedProcedures <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped procedures query executed successfully",
                                   connection = connection, cdmDomain = 'procedure', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedDevices <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped devices query executed successfully",
                                connection = connection, cdmDomain = 'device', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedVisits <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped visits query executed successfully",
                               connection = connection, cdmDomain = 'visit', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedVisitDetails <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped visit details query executed successfully",
                                     connection = connection, cdmDomain = 'visit_detail', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedUnitsMeas <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped meas units query executed successfully",
                                  connection = connection, cdmDomain = 'meas_unit', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedUnitsObs <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped obs units query executed successfully",
                                 connection = connection, cdmDomain = 'obs_unit', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedValuesMeas <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped meas values query executed successfully",
                                   connection = connection, cdmDomain = 'meas_value', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedValuesObs <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped obs values query executed successfully",
                                  connection = connection, cdmDomain = 'obs_value', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedDrugRoute <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped drug routes query executed successfully",
                                  connection = connection, cdmDomain = 'drug_route', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  mappedSpecialty <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped specialty query executed successfully",
                                  connection = connection, cdmDomain = 'specialty', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  if (cdmVersion >= 5.4) {
    mappedEpisodes <- executeQuery(outputFolder, "mapped_concepts_templated.sql", successMessage = "Mapped episodes query executed successfully",
                                   connection = connection, cdmDomain = 'eps', cdmDatabaseSchema = cdmDatabaseSchema, smallCellCount = smallCellCount)
  } else {
    mappedEpisodes <- NULL
  }

  list(
    version = conceptCounts$result[conceptCounts$result$ID == 'None', ]$VERSION,
    mappingTempTableCreation = mappingTempTableCreation,
    mappingCompleteness = mappingCompleteness,
    drugMapping = drugMapping,
    unmappedDrugs = unmappedDrugs,
    unmappedConditions = unmappedConditions,
    unmappedMeasurements = unmappedMeasurements,
    unmappedObservations = unmappedObservations,
    unmappedProcedures = unmappedProcedures,
    unmappedDevices = unmappedDevices,
    unmappedVisits = unmappedVisits,
    unmappedVisitDetails = unmappedVisitDetails,
    unmappedUnitsMeas = unmappedUnitsMeas,
    unmappedUnitsObs = unmappedUnitsObs,
    unmappedValuesMeas = unmappedValuesMeas,
    unmappedValuesObs = unmappedValuesObs,
    unmappedDrugRoute = unmappedDrugRoute,
    unmappedSpecialty = unmappedSpecialty,
    unmappedEpisodes = unmappedEpisodes,
    mappedDrugs = mappedDrugs,
    mappedConditions = mappedConditions,
    mappedMeasurements = mappedMeasurements,
    mappedObservations = mappedObservations,
    mappedProcedures = mappedProcedures,
    mappedDevices = mappedDevices,
    mappedVisits = mappedVisits,
    mappedVisitDetails = mappedVisitDetails,
    mappedUnitsMeas = mappedUnitsMeas,
    mappedUnitsObs = mappedUnitsObs,
    mappedValuesMeas = mappedValuesMeas,
    mappedValuesObs = mappedValuesObs,
    mappedDrugRoute = mappedDrugRoute,
    mappedSpecialty = mappedSpecialty,
    mappedEpisodes = mappedEpisodes,
    conceptCounts = conceptCounts,
    vocabularyCounts = vocabularyCounts,
    sourceConceptFrequency = sourceConceptFrequency,
    sourceConceptMap = sourceConceptMap
  )
}
