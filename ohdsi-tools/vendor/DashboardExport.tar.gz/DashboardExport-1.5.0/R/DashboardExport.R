# @file DashboardExport
#
# Copyright 2023 Darwin EU Coordination Center
#
# This file is part of the DashboardExport package
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# @author Darwin EU Coordination Center
# @author Maxim Moinat


#' dashboardExport
#'
#' @description
#' \code{dashboardExport} exports a set of descriptive statistics summary from the CDM,
#' to be uploaded in the Database Dashboard.
#'
#' @details
#' \code{dashboardExport} exports the results from Achilles, stored in the achilles_results
#' and achilles_results_dist tables, to a single csv file.
#' This csv file can be uploaded to the Database Dashboard entry in the DARWIN-EU(R) Portal.
#' There are two measures to prevent sharing of too detailed information:
#' 1. all counts are rounded up to the nearest hundred.
#' 2. a small cell count is applied and counts smaller than this record are omitted (default=5)
#' This is a light-weight version of the EHDEN CatalogueExport, where the Achilles analyses were rerun.
#'
#' @param connectionDetails        An R object of type \code{connectionDetails} created using the function
#'                                 \code{createConnectionDetails} or \code{createDbiConnectionDetails} in
#'                                 the \code{DatabaseConnector} package.
#' @param cdmDatabaseSchema    	   Fully qualified name of database schema that contains OMOP CDM schema.
#'                                 On SQL Server, this should specifiy both the database and the schema,
#'                                 so for example, on SQL Server, 'cdm_instance.dbo'.
#' @param resultsDatabaseSchema	   Fully qualified name of database schema that we can write results to.
#'                                 On SQL Server, this should specifiy both the database and the schema,
#'                                 so for example, on SQL Server, 'cdm_results.dbo'.
#' @param achillesDatabaseSchema   (OPTIONAL) Fully qualified name of database schema where the Achilles results
#'                                 tables can be found (achilles_results, achilles_results_dist).
#'                                 On SQL Server, this should specifiy both the database and the schema,
#'                                 so for example, on SQL Server, 'cdm_results.dbo'.
#' @param smallCellCount           (OPTIONAL) To avoid patient identifiability, cells with small counts
#'                                 (<= smallCellCount) are deleted. Set to NULL if you don't want any deletions.
#'                                 Default = 5.
#' @param outputFolder             (OPTIONAL) Path to write the export and store logs and SQL files. 
#'                                 If the path does not exist, it is created. Defaults to 'output'.
#' @param databaseId               (OPTIONAL) Name of the source, used in the filename exported. If not given, it is retrieved from cdm_source table.
#' @param cdmVersion               (OPTIONAL) Version number of the OMOP CDM. If not given, it is retrieved from cdm_source table.
#' @param verboseMode              (OPTIONAL) Boolean to determine if the console will show all execution steps. Default = TRUE
#' @return dataframe of exported results (invisibly)
#' @examples
#' \dontrun{
#' connectionDetails <- createConnectionDetails(dbms="sql server", server="your_server")
#' dashboardExport(
#'      connectionDetails = connectionDetails,
#'      cdmDatabaseSchema = "cdm",
#'      resultsDatabaseSchema = "results",
#'      outputFolder = "output",
#'      databaseId = "MyName"
#' )
#' }
#' @export
dashboardExport <- function(
  connectionDetails,
  cdmDatabaseSchema,
  resultsDatabaseSchema,
  achillesDatabaseSchema = resultsDatabaseSchema,
  smallCellCount = 5,
  outputFolder = "output",
  databaseId = NULL,
  cdmVersion = NULL,
  verboseMode = TRUE
) {
  # Setup logging
  ParallelLogger::clearLoggers()

  ParallelLogger::addDefaultFileLogger(file.path(outputFolder, "log_dashboardExport.txt"))
  ParallelLogger::addDefaultErrorReportLogger(file.path(outputFolder, "errorReportR.txt"))
  on.exit(ParallelLogger::unregisterLogger("DEFAULT_FILE_LOGGER", silent = TRUE))
  on.exit(ParallelLogger::unregisterLogger("DEFAULT_ERRORREPORT_LOGGER", silent = TRUE), add = TRUE)

  if (verboseMode) {
    ParallelLogger::registerLogger(
      ParallelLogger::createLogger(
        name = "DEFAULT_CONSOLE_LOGGER",
        threshold = "INFO",
        appenders = list(ParallelLogger::createConsoleAppender(layout = ParallelLogger::layoutTimestamp))
      )
    )
    on.exit(ParallelLogger::unregisterLogger("DEFAULT_CONSOLE_LOGGER"), add = TRUE)
  }

  ParallelLogger::logInfo(sprintf("Checking that Achilles results are available in schema '%s'", achillesDatabaseSchema))
  if (!.checkAchillesTablesExist(connectionDetails, achillesDatabaseSchema)) {
    ParallelLogger::logError("The output from the Achilles analyses is required.")
    ParallelLogger::logInfo(sprintf(
      "Please run Achilles first and make sure the resulting Achilles tables are in the given results schema ('%s').", # nolint
      achillesDatabaseSchema)
    )
    return(NULL)
  }

  # Check whether results for required Achilles analyses is available.
  # At least require person, obs. period, condition and drug exposure. Other domains can be empty.
  expectedAnalysisIds <- c(0, 1, 2, 3, 101, 102, 103, 105, 108, 110, 111, 113, 400, 401, 403, 405, 420, 700, 701, 703, 705, 720)
  analysisIdsAvailable <- .getAvailableAchillesAnalysisIds(connectionDetails, achillesDatabaseSchema)
  missingAnalysisIds <- setdiff(expectedAnalysisIds, analysisIdsAvailable)
  if (length(missingAnalysisIds) > 0) {
    ParallelLogger::logWarn(sprintf(
      "Missing results for the following Achilles analyses: %s.",
      paste(missingAnalysisIds, collapse = ", ")
    ))
    ParallelLogger::logWarn(
      "We are expecting at least results for the following tables: person (Achilles ids in range 1-20), observation period (100-120), condition occurrence (400-420) and drug exposure (700-720).\n> If the missing Achilles results are expected, press enter to continue. If not, abort (ctrl-c) and rerun Achilles including the above analysis ids." # nolint
    )
    readline("")
  }

  # Display Achilles metadata
  achillesMetadata <- .getAchillesMetadata(connectionDetails, achillesDatabaseSchema)
  ParallelLogger::logInfo(sprintf(
    "Achilles v%s results found. Executed on %s for '%s' (n=%dk).",
    achillesMetadata$ACHILLES_VERSION,
    achillesMetadata$ACHILLES_EXECUTION_DATE,
    achillesMetadata$ACHILLES_SOURCE_NAME,
    achillesMetadata$PERSON_COUNT_THOUSANDS
  ))

  # Create the export folder if it does not exist
  if (!file.exists(outputFolder)) {
    dir.create(outputFolder, recursive = TRUE)
  }

  if (is.null(databaseId)) {
    databaseId <- .getSourceName(connectionDetails, cdmDatabaseSchema)
  }

  if (is.null(cdmVersion)) {
    cdmVersion <- .getCdmVersion(connectionDetails, cdmDatabaseSchema)
  }

  renderedSql <- SqlRender::render(
    "SELECT COUNT(*) AS n FROM @cdm_database_schema.cdm_source;",
    cdm_database_schema = cdmDatabaseSchema
  )

  translatedSql <- SqlRender::translate(
    renderedSql,
    targetDialect = connectionDetails$dbms
  )

  connection <- DatabaseConnector::connect(connectionDetails = connectionDetails)
  cdm_source_count <- as.numeric(DatabaseConnector::querySql(connection, translatedSql, snakeCaseToCamelCase = TRUE)$n[1])

  if (cdm_source_count > 1) {
    ParallelLogger::logWarn(
      sprintf("CDM Source Check: Found %d rows in cdm_source where only one is expected. Using the row with the latest cdm_release_date.",
      cdm_source_count)
    )
  }
  DatabaseConnector::disconnect(connection = connection)

  .executeDEAnalyses(
    connectionDetails = connectionDetails,
    cdmDatabaseSchema = cdmDatabaseSchema,
    resultsDatabaseSchema = resultsDatabaseSchema,
    outputFolder = outputFolder,
    cdmVersion = cdmVersion
  )

  # Query and write results
  results <- exportResults(
    connectionDetails = connectionDetails,
    cdmDatabaseSchema = cdmDatabaseSchema,
    resultsDatabaseSchema = resultsDatabaseSchema,
    achillesDatabaseSchema = achillesDatabaseSchema,
    smallCellCount = smallCellCount,
    outputFolder = outputFolder,
    databaseId = databaseId
  )
  invisible(results)
}


.getSourceName <- function(connectionDetails, cdmDatabaseSchema) {
  sql <- SqlRender::render(
    sql = "select cdm_source_name from @cdmDatabaseSchema.cdm_source",
    cdmDatabaseSchema = cdmDatabaseSchema
  )
  sql <- SqlRender::translate(sql = sql, targetDialect = connectionDetails$dbms)
  connection <- DatabaseConnector::connect(connectionDetails = connectionDetails)
  sourceName <- tryCatch({
    s <- DatabaseConnector::querySql(connection = connection, sql = sql)
    s[1, ]
  }, error = function(e) {
    ""
  }, finally = {
    DatabaseConnector::disconnect(connection = connection)
    rm(connection)
  })
  sourceName
}

.getCdmVersion <- function(connectionDetails, cdmDatabaseSchema) {
  sql <- SqlRender::render(
    sql = "select cdm_version from @cdmDatabaseSchema.cdm_source",
    cdmDatabaseSchema = cdmDatabaseSchema
  )
  sql <- SqlRender::translate(sql = sql, targetDialect = connectionDetails$dbms)
  connection <- DatabaseConnector::connect(connectionDetails = connectionDetails)
  cdmVersion <- tryCatch({
    s <- DatabaseConnector::querySql(connection = connection, sql = sql)
    s[1, ]
  }, error = function(e) {
    ""
  }, finally = {
    DatabaseConnector::disconnect(connection = connection)
    rm(connection)
  })

  cdmVersion <- gsub(pattern = "v", replacement = "", cdmVersion)
  cdmVersion <- substr(cdmVersion, 1, 3)

  cdmVersion
}
