-- Export achilles results
-- Combines regular and _dist results into one output and adds custom analyses

-- Analysis 0 with run info, expected as first row in output
SELECT 
  0 as analysis_id,  
  stratum_1 as stratum_1, -- Achilles source name
  CAST('@package_version' AS VARCHAR(255)) as stratum_2, -- DashboardExport version
  CONVERT(VARCHAR,GETDATE(),112) as stratum_3, -- Date of export
  stratum_2 as stratum_4, -- Achilles version
  stratum_3 as stratum_5, -- Achilles execution date
  count_value as count_value, -- Achilles distinct person count
  cast(null as float) min_value,
  cast(null as float) max_value,
  cast(null as float) avg_value,
  cast(null as float) stdev_value,
  cast(null as float) median_value,
  cast(null as float) p10_value,
  cast(null as float) p25_value,
  cast(null as float) P75_value,
  cast(null as float) p90_value
FROM @achilles_database_schema.achilles_results
WHERE analysis_id = 0

UNION

-- Analysis 5000 with CDM source info, for convenience as first row in output
SELECT *,
  cast(null as float) min_value,
  cast(null as float) max_value,
  cast(null as float) avg_value,
  cast(null as float) stdev_value,
  cast(null as float) median_value,
  cast(null as float) p10_value,
  cast(null as float) p25_value,
  cast(null as float) P75_value,
  cast(null as float) p90_value
FROM @results_database_schema.@de_results_table
WHERE analysis_id = 5000

UNION

-- Combine Achilles and DashboardExport analysis results,
-- applying rounding and min cell count.
SELECT
  -- Re-id Achilles analysis_id xx30 to prevent clashes
  CASE 
    WHEN analysis_id in (430,630,730,830,1830,2130) THEN analysis_id + 10
    ELSE analysis_id 
  END as analysis_id,
  stratum_1,
  stratum_2,
  stratum_3,
  stratum_4,
  stratum_5,
  CASE
    -- Round up to nearest 10 in cases of total records by month, or persons in observation period by month
    WHEN analysis_id % 100 = 20 OR analysis_id IN (110, 111, 112) THEN floor((count_value+9)/10)*10
    -- Round up to nearest upper 100 value otherwise
    ELSE floor((count_value+99)/100)*100
  END AS count_value,
  min_value,
  max_value,
  round(avg_value, 5) as avg_value,
  round(stdev_value, 5) as stdev_value,
  median_value,
  p10_value,
  p25_value,
  P75_value,
  p90_value
FROM (
  -- Regular achilles_results
  SELECT *,
    cast(null as float) min_value,
    cast(null as float) max_value,
    cast(null as float) avg_value,
    cast(null as float) stdev_value,
    cast(null as float) median_value,
    cast(null as float) p10_value,
    cast(null as float) p25_value,
    cast(null as float) P75_value,
    cast(null as float) p90_value
  FROM @achilles_database_schema.achilles_results

  UNION ALL

  -- Regular achilles_results_dist
  SELECT *
  FROM @achilles_database_schema.achilles_results_dist

  UNION ALL

  -- DashboardExport-specific analyses
  SELECT *,
    cast(null as float) min_value,
    cast(null as float) max_value,
    cast(null as float) avg_value,
    cast(null as float) stdev_value,
    cast(null as float) median_value,
    cast(null as float) p10_value,
    cast(null as float) p25_value,
    cast(null as float) P75_value,
    cast(null as float) p90_value
  FROM @results_database_schema.@de_results_table

  UNION ALL

  -- DashboardExport-specific dist analyses
  SELECT *
  FROM @results_database_schema.@de_results_table_dist
) ar
WHERE count_value > @min_cell_count
  AND analysis_id NOT IN (0, 5000) -- already exported separately 
  AND analysis_id < 2000000 -- exclude timings
  {@analysis_ids != ''} ? {AND analysis_id IN (@analysis_ids)}
;
